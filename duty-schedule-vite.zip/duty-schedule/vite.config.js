import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

export default defineConfig({
  plugins: [react()],
  // ถ้า deploy บน GitHub Pages ให้เปลี่ยน base เป็นชื่อ repo
  // เช่น base: '/duty-schedule/'
  base: './',
})
