export const EMPLOYEES = [
  { id: '408876', nickname: 'บัญชา',    fullname: 'บัญชา วิวรรณพงษ์',     position: 'พชง.6', phone: '095-816-8291', role: 'หัวหน้าเวร' },
  { id: '503452', nickname: 'วัฒนะ',    fullname: 'วัฒนะ วงศ์ชมภู',        position: 'พชง.6', phone: '085-850-6719', role: 'หัวหน้าเวร' },
  { id: '512124', nickname: 'ยุรนันท์', fullname: 'ยุรนันท์ พิมพ์พัฒน์',   position: 'พชง.4', phone: '097-335-6193', role: 'หัวหน้าเวร' },
  { id: '506194', nickname: 'กฤษ',      fullname: 'กฤษ บุญภาย',            position: 'พชง.6', phone: '062-262-8999', role: 'หัวหน้าเวร' },
  { id: '513836', nickname: 'ธราดล',    fullname: 'ธราดล นันทร์แก้ว',      position: 'พชง.3', phone: '095-207-1311', role: 'พนักงานเวร' },
  { id: '512682', nickname: 'ธนารักษ์', fullname: 'ธนารักษ์ เล็กประเสริฐ', position: 'พชง.4', phone: '093-327-2955', role: 'พนักงานเวร' },
  { id: '513845', nickname: 'ธนพรรชน์', fullname: 'ธนพรรชน์ กลีบฉวี',     position: 'พชง.3', phone: '099-016-1125', role: 'พนักงานเวร' },
  { id: '513837', nickname: 'กษิดิศ',   fullname: 'กษิดิศ จันทร์เสละ',    position: 'พชง.3', phone: '098-130-4010', role: 'พนักงานเวร' },
]

export const INSPECTORS = [
  { id: '475718', nickname: 'ทรงคุณ', fullname: 'ทรงคุณ ทุมวัน',   position: 'หผ.บต.', phone: '081-321-3821' },
  { id: '497367', nickname: 'สรชา',   fullname: 'สรชา แสงอารมณ์',  position: 'ชผ.ปร.', phone: '098-645-9452' },
  { id: '437095', nickname: 'ธงชัย',  fullname: 'ธงชัย ตาลดง',     position: 'หผ.ปร.', phone: '081-059-5073' },
]

export const ELECTRICAL_WORKERS = [
  { id: 'A00001', fullname: 'มงคลชัย ทดคุย',      position: 'ผู้ปฏิบัติงานด้านระบบไฟฟ้า' },
  { id: 'A00002', fullname: 'จรูญ จันทะอุทัย',    position: 'ผู้ปฏิบัติงานด้านระบบไฟฟ้า' },
  { id: 'A00003', fullname: 'ศตวรรษ พิลุน',       position: 'ผู้ปฏิบัติงานด้านระบบไฟฟ้า' },
  { id: 'A00004', fullname: 'สุนทร สะตะ',         position: 'ผู้ปฏิบัติงานด้านระบบไฟฟ้า' },
  { id: 'A00005', fullname: 'ธีรพงษ์ เนื่องแก้ว', position: 'ผู้ปฏิบัติงานด้านระบบไฟฟ้า' },
]

/** สีประจำตัวพนักงานแต่ละคน */
export const NICK_COLORS = {
  บัญชา:    { bg: '#ffd6d6', color: '#7a0000' },
  วัฒนะ:    { bg: '#cce5ff', color: '#003d7a' },
  ยุรนันท์: { bg: '#d0f5d0', color: '#1a5c00' },
  กฤษ:      { bg: '#fff3cc', color: '#7a5500' },
  ธราดล:    { bg: '#f0d6ff', color: '#5c0070' },
  ธนารักษ์: { bg: '#ccf5ef', color: '#005c4a' },
  ธนพรรชน์: { bg: '#ffd6ef', color: '#7a0050' },
  กษิดิศ:   { bg: '#dde6ff', color: '#1a2d7a' },
}

export const getEmp  = (nick) => EMPLOYEES.find(e => e.nickname === nick)
export const getInsp = (nick) => INSPECTORS.find(e => e.nickname === nick)
