export const SHIFT_KEYS   = ['shift0030', 'shift0830', 'shift1630']
export const SHIFT_LABELS = {
  shift0030: '00.30-08.30 น.',
  shift0830: '08.30-16.30 น.',
  shift1630: '16.30-00.30 น.',
}
export const SHIFT_SHORT = {
  shift0030: '00.30-08.30',
  shift0830: '08.30-16.30',
  shift1630: '16.30-00.30',
}

export const fmtDate = (day) => `${String(day).padStart(2, '0')}/03/2569`

/** ตารางเวร มีนาคม พ.ศ. 2569 (อัปเดตตามภาพที่ 2 รวม handwriting) */
export const INITIAL_SCHEDULE = [
  { day:1,  shift0030:['ธนารักษ์'],    shift0830:['วัฒนะ','ธราดล'],      shift1630:['กฤษ','ธนพรรชน์'],     standby:'ยุรนันท์', note:'อาทิตย์', inspector:'ธงชัย' },
  { day:2,  shift0030:['ธนพรรชน์'],    shift0830:[],                      shift1630:['ยุรนันท์','กษิดิศ'],  standby:'กฤษ',      note:'',         inspector:'สรชา'  },
  { day:3,  shift0030:['กษิดิศ'],      shift0830:['ยุรนันท์','ธนารักษ์'], shift1630:['กฤษ','ธราดล'],        standby:'ยุรนันท์', note:'หยุด',     inspector:'ธงชัย' },
  { day:4,  shift0030:['ธราดล'],       shift0830:[],                      shift1630:['ยุรนันท์','ธนพรรชน์'],standby:'กฤษ',      note:'',         inspector:'สรชา'  },
  { day:5,  shift0030:['ธนพรรชน์'],    shift0830:[],                      shift1630:['วัฒนะ','กษิดิศ'],     standby:'ยุรนันท์', note:'',         inspector:'ธงชัย' },
  { day:6,  shift0030:['กษิดิศ'],      shift0830:['วัฒนะ'],               shift1630:['กฤษ','ธนารักษ์'],     standby:'วัฒนะ',    note:'',         inspector:'สรชา'  },
  { day:7,  shift0030:['ธนารักษ์'],    shift0830:['ยุรนันท์','ธราดล'],    shift1630:['วัฒนะ','ธนพรรชน์'],   standby:'กฤษ',      note:'เสาร์',    inspector:'ธงชัย' },
  { day:8,  shift0030:['ธนพรรชน์'],    shift0830:['กฤษ','กษิดิศ'],        shift1630:['ยุรนันท์','ธนารักษ์'],standby:'วัฒนะ',    note:'อาทิตย์',  inspector:'สรชา'  },
  { day:9,  shift0030:['ธนารักษ์'],    shift0830:['ยุรนันท์'],            shift1630:['วัฒนะ','ธราดล'],       standby:'ยุรนันท์', note:'',         inspector:'ธงชัย' },
  { day:10, shift0030:['ธราดล'],       shift0830:[],                      shift1630:['กฤษ','ธนพรรชน์'],      standby:'วัฒนะ',    note:'',         inspector:'สรชา'  },
  { day:11, shift0030:['ธนพรรชน์'],    shift0830:[],                      shift1630:['ยุรนันท์','กษิดิศ'],   standby:'กฤษ',      note:'',         inspector:'ธงชัย' },
  { day:12, shift0030:['กษิดิศ'],      shift0830:['ยุรนันท์'],            shift1630:['วัฒนะ','ธนารักษ์'],    standby:'ยุรนันท์', note:'',         inspector:'สรชา'  },
  { day:13, shift0030:['ธนารักษ์'],    shift0830:[],                      shift1630:['กฤษ','ธราดล'],          standby:'วัฒนะ',    note:'',         inspector:'ธงชัย' },
  { day:14, shift0030:['ธราดล'],       shift0830:['กฤษ'],                 shift1630:['วัฒนะ','กษิดิศ'],       standby:'กฤษ',      note:'เสาร์',    inspector:'สรชา'  },
  { day:15, shift0030:['กษิดิศ'],      shift0830:['ยุรนันท์','ธนพรรชน์'],shift1630:['วัฒนะ','ธนารักษ์'],     standby:'วัฒนะ',    note:'อาทิตย์',  inspector:'ธงชัย' },
  { day:16, shift0030:['ธราดล'],       shift0830:['กฤษ','ธนารักษ์'],      shift1630:['ยุรนันท์','ธราดล'],     standby:'ยุรนันท์', note:'',         inspector:'สรชา'  },
  { day:17, shift0030:['ธนพรรชน์'],    shift0830:[],                      shift1630:['วัฒนะ','ธนพรรชน์'],     standby:'วัฒนะ',    note:'',         inspector:'ธงชัย' },
  { day:18, shift0030:['กษิดิศ'],      shift0830:['ยุรนันท์'],            shift1630:['กฤษ','กษิดิศ'],          standby:'กฤษ',      note:'',         inspector:'สรชา'  },
  { day:19, shift0030:['ธนารักษ์'],    shift0830:[],                      shift1630:['ยุรนันท์','ธนารักษ์'],   standby:'ยุรนันท์', note:'',         inspector:'ธงชัย' },
  { day:20, shift0030:['ธราดล'],       shift0830:[],                      shift1630:['กฤษ','ธนพรรชน์'],        standby:'วัฒนะ',    note:'',         inspector:'สรชา'  },
  { day:21, shift0030:['ธนพรรชน์'],    shift0830:['ยุรนันท์','ธนารักษ์'],shift1630:['วัฒนะ','กษิดิศ'],        standby:'กฤษ',      note:'เสาร์',    inspector:'ธงชัย' },
  { day:22, shift0030:['ธนารักษ์'],    shift0830:['กฤษ','ธราดล'],         shift1630:['ยุรนันท์','ธนพรรชน์'],  standby:'วัฒนะ',    note:'อาทิตย์',  inspector:'สรชา'  },
  { day:23, shift0030:['ธนพรรชน์'],    shift0830:[],                      shift1630:['วัฒนะ','กษิดิศ'],        standby:'ยุรนันท์', note:'',         inspector:'ธงชัย' },
  { day:24, shift0030:['กษิดิศ'],      shift0830:[],                      shift1630:['กฤษ','ธนารักษ์'],        standby:'วัฒนะ',    note:'',         inspector:'สรชา'  },
  { day:25, shift0030:['ธนารักษ์'],    shift0830:[],                      shift1630:['ยุรนันท์','ธราดล'],      standby:'กฤษ',      note:'',         inspector:'ธงชัย' },
  { day:26, shift0030:['ธราดล'],       shift0830:[],                      shift1630:['วัฒนะ','ธนพรรชน์'],      standby:'ยุรนันท์', note:'',         inspector:'สรชา'  },
  { day:27, shift0030:['ธนพรรชน์'],    shift0830:[],                      shift1630:['กฤษ','กษิดิศ'],          standby:'วัฒนะ',    note:'',         inspector:'ธงชัย' },
  { day:28, shift0030:['กษิดิศ'],      shift0830:['ยุรนันท์','ธนารักษ์'],shift1630:['วัฒนะ','ธราดล'],          standby:'กฤษ',      note:'เสาร์',    inspector:'สรชา'  },
  { day:29, shift0030:['ธราดล'],       shift0830:['กฤษ','ธนพรรชน์'],      shift1630:['ยุรนันท์','กษิดิศ'],    standby:'วัฒนะ',    note:'อาทิตย์',  inspector:'ธงชัย' },
  { day:30, shift0030:['กษิดิศ'],      shift0830:[],                      shift1630:['วัฒนะ','ธนารักษ์'],      standby:'ยุรนันท์', note:'',         inspector:'สรชา'  },
  { day:31, shift0030:['ธนารักษ์'],    shift0830:[],                      shift1630:['กฤษ','ธราดล'],           standby:'วัฒนะ',    note:'',         inspector:'ธงชัย' },
]
