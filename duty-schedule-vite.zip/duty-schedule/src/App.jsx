import { useState, useCallback } from 'react'
import { EMPLOYEES, ELECTRICAL_WORKERS } from './data/employees'
import { INSPECTORS } from './data/employees'
import { INITIAL_SCHEDULE, SHIFT_KEYS, SHIFT_SHORT } from './data/schedule'
import { fmtDate } from './data/schedule'
import { NickChip, ShiftCells, NickBadge } from './components/ui/NickChip'
import Overlay from './components/ui/Overlay'
import EditModal from './components/EditModal'
import ReportModal from './components/ReportModal'

export default function App() {
  const [schedule,    setSchedule]    = useState(INITIAL_SCHEDULE);
  const [view,        setView]        = useState("schedule");
  const [shiftView,   setShiftView]   = useState("shift1630");
  const [editEntry,   setEditEntry]   = useState(null);
  const [reportEntry, setReportEntry] = useState(null);
  const [changes,     setChanges]     = useState({});

  const today = new Date();
  const isThisMonth = today.getFullYear()===2026 && today.getMonth()===2;
  const todayDay    = isThisMonth ? today.getDate() : null;
  const todayEntry  = schedule.find(s=>s.day===todayDay);

  const handleSave = useCallback((day, form) => {
    setSchedule(prev => prev.map(e => e.day===day ? {...e,...form} : e));
    setChanges(c => ({...c,[day]:true}));
    setEditEntry(null);
  }, []);

  const resetDay = (day) => {
    const orig = INITIAL_SCHEDULE.find(e=>e.day===day);
    setSchedule(prev => prev.map(e => e.day===day ? {...orig} : e));
    setChanges(c => { const n={...c}; delete n[day]; return n; });
  };

  const changedCount = Object.keys(changes).length;

  return (
    <div style={{minHeight:"100vh",background:"linear-gradient(135deg,#0a1628 0%,#1a2e5a 55%,#0e2044 100%)",fontFamily:"Sarabun,sans-serif"}}>

      {/* ── Header ── */}
      <div style={{background:"linear-gradient(90deg,#0d2045,#1a3a6b)",borderBottom:"2px solid #FFD700"}}>
        <div style={{maxWidth:980,margin:"0 auto",padding:"14px 16px",display:"flex",alignItems:"center",gap:14,flexWrap:"wrap"}}>
          <div style={{width:48,height:48,borderRadius:"50%",background:"#FFD700",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,fontSize:24}}>⚡</div>
          <div style={{flex:1,minWidth:160}}>
            <div style={{color:"#FFD700",fontWeight:800,fontSize:17,letterSpacing:0.5}}>ระบบจัดการตารางเวร</div>
            <div style={{color:"#a0c4ff",fontSize:12}}>แก้กระแสไฟฟ้าขัดข้อง • กฟส.ชยน. • มีนาคม 2569</div>
          </div>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {[{k:"schedule",l:"ตารางเวร",ic:"📅"},{k:"employees",l:"พนักงาน",ic:"👥"},{k:"report",l:"รายงาน",ic:"📋"}].map(t=>(
              <button key={t.k} onClick={()=>setView(t.k)} style={{
                padding:"8px 14px",borderRadius:10,border:"none",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"Sarabun,sans-serif",
                background: view===t.k?"#FFD700":"rgba(255,255,255,0.1)",
                color:      view===t.k?"#0d2045":"#a0c4ff"}}>
                {t.ic} {t.l}
              </button>
            ))}
          </div>
        </div>
      </div>

      <div style={{maxWidth:980,margin:"0 auto",padding:"20px 16px"}}>

        {/* today banner */}
        {view==="schedule" && todayEntry && (
          <div style={{background:"linear-gradient(90deg,#FFD700,#ffc107)",borderRadius:16,padding:"13px 18px",marginBottom:18,display:"flex",alignItems:"center",gap:12,flexWrap:"wrap",boxShadow:"0 4px 24px rgba(255,200,0,0.3)"}}>
            <div style={{flex:1,minWidth:200}}>
              <div style={{fontWeight:700,fontSize:15,color:"#0d2045"}}>⚡ เวรวันนี้ — วันที่ {todayDay} มีนาคม 2569</div>
              <div style={{fontSize:13,color:"#1a3a6b",marginTop:2}}>
                16.30-00.30: {todayEntry.shift1630.join(", ")} &nbsp;•&nbsp; Standby: {todayEntry.standby} &nbsp;•&nbsp; ผู้ตรวจ: {todayEntry.inspector}
              </div>
            </div>
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>setEditEntry({...todayEntry})} style={{padding:"8px 16px",borderRadius:10,border:"2px solid #0d2045",background:"#0d2045",color:"#FFD700",fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"Sarabun,sans-serif"}}>✏️ แก้ไข</button>
              <button onClick={()=>setReportEntry(todayEntry)}    style={{padding:"8px 16px",borderRadius:10,border:"2px solid #0d2045",background:"white",  color:"#0d2045",fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"Sarabun,sans-serif"}}>📋 รายงาน</button>
            </div>
          </div>
        )}

        {/* ── Schedule View ── */}
        {view==="schedule" && (
          <div>
            <div style={{display:"flex",alignItems:"center",gap:10,marginBottom:14,flexWrap:"wrap"}}>
              <div style={{color:"white",fontWeight:700,fontSize:16}}>📅 ตารางเวร มีนาคม 2569</div>
              {changedCount>0 && (
                <span style={{background:"rgba(255,165,0,0.25)",color:"#ffa500",borderRadius:8,padding:"2px 10px",fontSize:12,border:"1px solid rgba(255,165,0,0.4)"}}>
                  ✏️ แก้ไขแล้ว {changedCount} วัน
                </span>
              )}
            </div>

            {/* color legend */}
            <div style={{display:"flex",gap:6,flexWrap:"wrap",marginBottom:12}}>
              {[
                {nick:"บัญชา",    color:"#ffd6d6"},
                {nick:"วัฒนะ",    color:"#d6eaff"},
                {nick:"ยุรนันท์", color:"#d6ffd6"},
                {nick:"กฤษ",      color:"#fff3d6"},
                {nick:"ธราดล",    color:"#f0d6ff"},
                {nick:"ธนารักษ์", color:"#d6fff6"},
                {nick:"ธนพรรชน์", color:"#ffd6f0"},
                {nick:"กษิดิศ",   color:"#e0e8ff"},
              ].map(e=>(
                <span key={e.nick} style={{padding:"3px 10px",borderRadius:99,fontSize:11,fontFamily:"Sarabun,sans-serif",fontWeight:600,background:e.color,color:"#222",border:"1px solid rgba(0,0,0,0.12)"}}>
                  {e.nick}
                </span>
              ))}
            </div>

            <div style={{overflowX:"auto",borderRadius:16,border:"1px solid rgba(255,255,255,0.1)"}}>
              <table style={{width:"100%",borderCollapse:"collapse",minWidth:700}}>
                <thead>
                  <tr style={{background:"rgba(20,45,100,0.98)"}}>
                    <th style={{padding:"10px 8px",color:"#FFD700",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",width:42}}>วันที่</th>
                    <th style={{padding:"10px 8px",color:"#a0d4ff",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>00.30 – 08.30</th>
                    <th style={{padding:"10px 8px",color:"#a0ffa0",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>08.30 – 16.30</th>
                    <th style={{padding:"10px 8px",color:"#ffd6a0",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>16.30 – 00.30</th>
                    <th style={{padding:"10px 8px",color:"#d0c4ff",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>Standby<br/><span style={{fontSize:10,opacity:0.7}}>(00.30-08.30)</span></th>
                    <th style={{padding:"10px 8px",color:"#FFD700",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>หมายเหตุ</th>
                    <th style={{padding:"10px 8px",color:"#FFD700",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>ผู้ตรวจเวร</th>
                    <th style={{padding:"10px 8px",color:"#FFD700",fontFamily:"Sarabun,sans-serif",fontSize:12,textAlign:"center",whiteSpace:"nowrap",borderLeft:"1px solid rgba(255,255,255,0.1)"}}>จัดการ</th>
                  </tr>
                </thead>
                <tbody>
                  {schedule.map((entry, idx) => {
                    const isToday   = entry.day===todayDay;
                    const isWeekend = ["เสาร์","อาทิตย์","หยุด"].includes(entry.note);
                    const isChanged = !!changes[entry.day];
                    const rowBg = isToday
                      ? "rgba(255,215,0,0.13)"
                      : isWeekend
                        ? "rgba(255,255,255,0.04)"
                        : idx%2===0 ? "rgba(255,255,255,0.02)" : "transparent";
                    return (
                      <tr key={entry.day} style={{background:rowBg, borderBottom:"1px solid rgba(255,255,255,0.06)", transition:"background 0.15s"}}>

                        {/* วันที่ */}
                        <td style={{padding:"7px 6px",textAlign:"center",fontWeight:700,fontSize:13,
                          color: isToday?"#FFD700": isWeekend?"#ffa07a":"#a0c4ff",
                          borderRight:"1px solid rgba(255,255,255,0.06)",whiteSpace:"nowrap"}}>
                          {isToday&&<span style={{fontSize:9}}>⚡</span>}{entry.day}
                          {isChanged&&<span style={{display:"block",color:"#ffa500",fontSize:8,lineHeight:1}}>●แก้</span>}
                        </td>

                        {/* กะ 00.30-08.30 */}
                        <td style={{padding:"6px 8px",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          <ShiftCells nicks={entry.shift0030} />
                        </td>

                        {/* กะ 08.30-16.30 */}
                        <td style={{padding:"6px 8px",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          <ShiftCells nicks={entry.shift0830} />
                        </td>

                        {/* กะ 16.30-00.30 */}
                        <td style={{padding:"6px 8px",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          <ShiftCells nicks={entry.shift1630} />
                        </td>

                        {/* Standby */}
                        <td style={{padding:"6px 8px",textAlign:"center",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          {entry.standby ? <NickChip nick={entry.standby} /> : <span style={{color:"rgba(255,255,255,0.15)",fontSize:11}}>—</span>}
                        </td>

                        {/* หมายเหตุ */}
                        <td style={{padding:"6px 8px",textAlign:"center",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          {isWeekend
                            ? <span style={{background:"rgba(255,100,50,0.25)",color:"#ffaa80",borderRadius:6,padding:"2px 7px",fontSize:11,fontWeight:600}}>{entry.note}</span>
                            : <span style={{color:"rgba(255,255,255,0.12)",fontSize:11}}>—</span>}
                        </td>

                        {/* ผู้ตรวจ */}
                        <td style={{padding:"6px 8px",textAlign:"center",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          <span style={{color: entry.inspector==="ธงชัย"?"#a0d4ff":"#ffd6a0", fontSize:12, fontFamily:"Sarabun,sans-serif",fontWeight:600}}>{entry.inspector}</span>
                        </td>

                        {/* จัดการ */}
                        <td style={{padding:"6px 6px",textAlign:"center",borderLeft:"1px solid rgba(255,255,255,0.06)"}}>
                          <div style={{display:"flex",gap:3,justifyContent:"center"}}>
                            <button onClick={()=>setEditEntry({...entry})} title="แก้ไข / สลับเวร" style={{padding:"4px 7px",borderRadius:7,border:"1px solid rgba(100,160,255,0.3)",background:"rgba(100,160,255,0.1)",color:"#6dd5fa",fontSize:12,cursor:"pointer"}}>✏️</button>
                            <button onClick={()=>setReportEntry(entry)}     title="ออกรายงาน"     style={{padding:"4px 7px",borderRadius:7,border:"1px solid rgba(255,215,0,0.25)",background:"rgba(255,215,0,0.08)",color:"#FFD700",fontSize:12,cursor:"pointer"}}>📋</button>
                            {isChanged&&(
                              <button onClick={()=>resetDay(entry.day)} title="คืนค่าเดิม" style={{padding:"4px 7px",borderRadius:7,border:"1px solid rgba(255,100,100,0.3)",background:"rgba(255,100,100,0.08)",color:"#f87171",fontSize:12,cursor:"pointer"}}>↩️</button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>

            <div style={{marginTop:10,fontSize:11,color:"rgba(255,255,255,0.3)",textAlign:"right"}}>
              ★ = หัวหน้าเวร &nbsp;|&nbsp; ● = แก้ไขแล้ว &nbsp;|&nbsp; ↩️ = คืนค่าเดิม
            </div>
          </div>
        )}

        {/* ── Employees View ── */}
        {view==="employees" && (
          <div>
            <div style={{color:"white",fontWeight:700,fontSize:16,marginBottom:16}}>👥 รายชื่อพนักงาน</div>
            {[
              {title:"⚡ พนักงานเข้าเวร",          list:EMPLOYEES,          bg:"#1a3a6b",ac:"#FFD700",  sub:e=>`${e.position} • ${e.role}`, ph:true},
              {title:"🔍 ผู้ตรวจเวร",              list:INSPECTORS,         bg:"#4a3000",ac:"#FFD700",  sub:e=>e.position,                  ph:true},
              {title:"🔧 ผู้ปฏิบัติงานระบบไฟฟ้า", list:ELECTRICAL_WORKERS, bg:"#1a4a2a",ac:"#7fff7f",  sub:e=>e.position,                  ph:false},
            ].map(sec=>(
              <div key={sec.title} style={{marginBottom:24}}>
                <div style={{color:"#FFD700",fontWeight:700,fontSize:14,marginBottom:10}}>{sec.title}</div>
                <div style={{display:"grid",gap:10,gridTemplateColumns:"repeat(auto-fill,minmax(240px,1fr))"}}>
                  {sec.list.map(emp=>(
                    <div key={emp.id} style={{background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.09)",borderRadius:14,padding:"14px 16px",display:"flex",alignItems:"center",gap:12}}>
                      <div style={{width:44,height:44,borderRadius:"50%",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",background:`linear-gradient(135deg,${sec.bg},${sec.bg}bb)`,border:`2px solid ${sec.ac}33`}}>
                        <span style={{color:sec.ac,fontWeight:700,fontSize:15}}>{(emp.nickname||emp.fullname)[0]}</span>
                      </div>
                      <div>
                        <div style={{color:"white",fontWeight:700,fontSize:14,fontFamily:"Sarabun,sans-serif"}}>{emp.fullname||emp.nickname}</div>
                        <div style={{color:"#a0c4ff",fontSize:12}}>{sec.sub(emp)}</div>
                        {sec.ph&&emp.phone&&<div style={{color:"#6dd5fa",fontSize:12}}>📞 {emp.phone}</div>}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── Report Picker ── */}
        {view==="report" && (
          <div>
            <div style={{color:"white",fontWeight:700,fontSize:16,marginBottom:16}}>📋 เลือกวันที่ต้องการออกรายงาน</div>
            <div style={{display:"grid",gap:8,gridTemplateColumns:"repeat(auto-fill,minmax(105px,1fr))"}}>
              {schedule.map(entry=>(
                <button key={entry.day} onClick={()=>setReportEntry(entry)} style={{
                  borderRadius:14,padding:"12px 8px",textAlign:"center",cursor:"pointer",
                  fontFamily:"Sarabun,sans-serif",
                  background:"rgba(255,255,255,0.05)",
                  border: entry.day===todayDay?"2px solid #FFD700":"1px solid rgba(255,255,255,0.1)",
                  color:  entry.day===todayDay?"#FFD700":"#a0c4ff"}}>
                  <div style={{fontWeight:700,fontSize:22}}>{entry.day}</div>
                  <div style={{fontSize:11,opacity:0.55}}>มี.ค. 2569</div>
                  {entry.note&&<div style={{fontSize:10,color:"rgba(255,215,0,0.8)",marginTop:2}}>{entry.note}</div>}
                  <div style={{marginTop:4}}>
                    {entry.shift1630[0]
                      ? <NickBadge nick={entry.shift1630[0]} isHead small/>
                      : <span style={{fontSize:10,color:"#555"}}>—</span>}
                  </div>
                  {changes[entry.day]&&<div style={{fontSize:9,color:"#ffa500",marginTop:3}}>● แก้ไขแล้ว</div>}
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* footer */}
      <div style={{textAlign:"center",color:"rgba(255,255,255,0.22)",fontSize:12,padding:"20px 0 14px",fontFamily:"Sarabun,sans-serif"}}>
        ระบบจัดการตารางเวรแก้กระแสไฟฟ้าขัดข้อง • การไฟฟ้าส่วนภูมิภาค สาขา ชยน.
      </div>

      {/* modals */}
      {editEntry && (
        <Overlay onClose={()=>setEditEntry(null)}>
          <EditModal entry={editEntry} onSave={handleSave} onClose={()=>setEditEntry(null)} />
        </Overlay>
      )}
      {reportEntry && (
        <Overlay onClose={()=>setReportEntry(null)}>
          <ReportModal entry={reportEntry} onClose={()=>setReportEntry(null)} />
        </Overlay>
      )}
    </div>
  );
}
