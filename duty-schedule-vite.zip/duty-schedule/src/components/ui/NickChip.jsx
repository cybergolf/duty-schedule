import { NICK_COLORS } from '../../data/employees'

export function NickChip({ nick, isHead }) {
  const c = NICK_COLORS[nick] || { bg: '#e8e8e8', color: '#333' }
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 2,
        padding: '2px 8px', borderRadius: 99,
        fontSize: 11, fontFamily: 'Sarabun, sans-serif',
        fontWeight: isHead ? 700 : 600,
        background: c.bg, color: c.color,
        border: `1px solid ${c.color}33`,
        whiteSpace: 'nowrap',
      }}
    >
      {isHead && <span style={{ fontSize: 9 }}>★</span>}
      {nick}
    </span>
  )
}

export function ShiftCells({ nicks }) {
  if (!nicks || nicks.length === 0)
    return (
      <span style={{ color: 'rgba(255,255,255,0.15)', fontSize: 11, display: 'block', textAlign: 'center' }}>
        —
      </span>
    )
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, justifyContent: 'center' }}>
      {nicks.map((n, i) => (
        <NickChip key={n + i} nick={n} isHead={i === 0} />
      ))}
    </div>
  )
}

/** Badge แบบเดิม (ใช้ใน report picker) */
export function NickBadge({ nick, isHead, small }) {
  return (
    <span
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 2,
        padding: small ? '1px 6px' : '2px 8px',
        borderRadius: 99, fontSize: small ? 10 : 11,
        fontFamily: 'Sarabun, sans-serif',
        fontWeight: isHead ? 700 : 500,
        background: isHead ? '#1a3a6b' : '#e8f0fb',
        color: isHead ? '#FFD700' : '#1a3a6b',
        border: isHead ? 'none' : '1px solid #b0c8e8',
        whiteSpace: 'nowrap',
      }}
    >
      {isHead && '★'}{nick}
    </span>
  )
}
