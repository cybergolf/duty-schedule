export default function Overlay({ children, onClose }) {
  return (
    <div
      onClick={onClose}
      style={{
        position: 'fixed', inset: 0, zIndex: 50,
        background: 'rgba(0,15,50,0.8)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        padding: 16,
      }}
    >
      <div
        onClick={e => e.stopPropagation()}
        style={{
          background: '#fff', borderRadius: 20,
          width: '100%', maxWidth: 700, maxHeight: '92vh',
          overflowY: 'auto', position: 'relative',
          border: '2px solid #1a3a6b',
          boxShadow: '0 24px 80px rgba(0,0,0,0.6)',
        }}
      >
        <button
          onClick={onClose}
          style={{
            position: 'absolute', top: 12, right: 16,
            fontSize: 24, fontWeight: 700, color: '#aaa',
            background: 'none', border: 'none', cursor: 'pointer',
            lineHeight: 1, zIndex: 2,
          }}
        >×</button>
        {children}
      </div>
    </div>
  )
}
