import { useState, useMemo, useRef } from 'react'
import { ELECTRICAL_WORKERS, getEmp, getInsp } from '../data/employees'
import { SHIFT_KEYS, SHIFT_LABELS, fmtDate } from '../data/schedule'

function ReportModal({ entry, onClose }) {
  const [selShift,   setSelShift]   = useState("shift1630");
  const [selWorkers, setSelWorkers] = useState([ELECTRICAL_WORKERS[3], ELECTRICAL_WORKERS[0]]);
  const [repDate,    setRepDate]    = useState(fmtDate(entry.day));
  const [copyStatus, setCopyStatus] = useState("idle"); // idle | success | manual

  const dutyList = entry[selShift] || [];

  // Plain text for clipboard (exact format required)
  const text = useMemo(() => {
    const head = getEmp(dutyList[0]);
    const insp = getInsp(entry.inspector);
    const lines = [
      `เรียน ผจก.กฟส.ชยน.ผ่าน หผ.ปร.`,
      `ลว. ${repDate}         เวลา ${SHIFT_LABELS[selShift]} `,
      `พนักงานอยู่เวรแก้กระแสไฟฟ้าขัดข้อง ดังนี้ `,
    ];
    let n = 1;
    if (head) { lines.push(`${n}. นาย ${head.fullname} หัวหน้าเวร เบอร์โทรศัพท์  ${head.phone}`); n++; }
    dutyList.slice(1).forEach(nick => {
      const e = getEmp(nick);
      if (e) { lines.push(`${n}. นาย ${e.fullname}   พนักงานเวร `); n++; }
    });
    selWorkers.forEach(w => {
      if (w) { lines.push(`${n}. นาย ${w.fullname} ${w.position} `); n++; }
    });
    if (insp) { lines.push(`${n}. นาย ${insp.fullname} ตำแหน่ง ${insp.position} `); n++; }
    lines.push(`${n}. ระบบสื่อสารเหตุการณ์ทั่วไป ปกติ `); n++;
    lines.push(`${n}. ไม่มีกระแสไฟฟ้าขัดข้องครับ `); n++;
    lines.push(`${n}. โทร.043-781048`);
    return lines.join("\n");
  }, [entry, selShift, selWorkers, repDate, dutyList]);

  // Rich preview rows
  const previewRows = useMemo(() => {
    const head = getEmp(dutyList[0]);
    const insp = getInsp(entry.inspector);
    const rows = [];
    let n = 1;
    if (head) { rows.push({ n, icon:"👑", text:`นาย ${head.fullname}`, sub:`หัวหน้าเวร  📞 ${head.phone}`, color:"#1a3a6b", bg:"#eef4ff" }); n++; }
    dutyList.slice(1).forEach(nick => {
      const e = getEmp(nick);
      if (e) { rows.push({ n, icon:"👤", text:`นาย ${e.fullname}`, sub:"พนักงานเวร", color:"#2d5a9e", bg:"#f5f8ff" }); n++; }
    });
    selWorkers.forEach(w => {
      if (w) { rows.push({ n, icon:"🔧", text:`นาย ${w.fullname}`, sub:w.position, color:"#1a5c2a", bg:"#f0faf3" }); n++; }
    });
    if (insp) { rows.push({ n, icon:"🔍", text:`นาย ${insp.fullname}`, sub:`ตำแหน่ง ${insp.position}`, color:"#7c4a00", bg:"#fffbf0" }); n++; }
    rows.push({ n, icon:"📡", text:"ระบบสื่อสารเหตุการณ์ทั่วไป ปกติ", sub:"", color:"#555", bg:"#fafafa" }); n++;
    rows.push({ n, icon:"✅", text:"ไม่มีกระแสไฟฟ้าขัดข้องครับ", sub:"", color:"#166534", bg:"#f0fdf4" }); n++;
    rows.push({ n, icon:"📞", text:"โทร.043-781048", sub:"", color:"#333", bg:"#fafafa" });
    return rows;
  }, [entry, selShift, selWorkers]);

  const textareaRef = useRef(null);

  const handleCopy = () => {
    if (textareaRef.current) {
      textareaRef.current.select();
      textareaRef.current.setSelectionRange(0, 99999);
      try {
        const ok = document.execCommand("copy");
        if (ok) { setCopyStatus("success"); setTimeout(() => setCopyStatus("idle"), 2500); return; }
      } catch(e) {}
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text)
        .then(() => { setCopyStatus("success"); setTimeout(() => setCopyStatus("idle"), 2500); })
        .catch(() => setCopyStatus("manual"));
    } else {
      setCopyStatus("manual");
    }
  };

  return (
    <div style={{fontFamily:"Sarabun,sans-serif",overflow:"hidden"}}>
      {/* ── Modal Header Banner ── */}
      <div style={{background:"linear-gradient(135deg,#0d2045 0%,#1a3a6b 100%)",padding:"20px 24px 16px",position:"relative",overflow:"hidden"}}>
        <div style={{position:"absolute",top:-20,right:-20,width:100,height:100,borderRadius:"50%",background:"rgba(255,215,0,0.08)"}}/>
        <div style={{position:"absolute",bottom:-30,right:60,width:70,height:70,borderRadius:"50%",background:"rgba(255,215,0,0.05)"}}/>
        <div style={{display:"flex",alignItems:"center",gap:14,position:"relative"}}>
          <div style={{width:52,height:52,borderRadius:"50%",background:"rgba(255,215,0,0.15)",border:"2px solid rgba(255,215,0,0.4)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
            <span style={{fontSize:26}}>⚡</span>
          </div>
          <div>
            <div style={{color:"#FFD700",fontWeight:800,fontSize:18,letterSpacing:0.5}}>รายงานเวร กฟส.ชยน.</div>
            <div style={{color:"#a0c4ff",fontSize:13,marginTop:2}}>📅 วันที่ {entry.day} มีนาคม พ.ศ. 2569 &nbsp;•&nbsp; 🕐 {SHIFT_LABELS[selShift]}</div>
          </div>
          <div style={{marginLeft:"auto",textAlign:"right"}}>
            <div style={{color:"rgba(255,255,255,0.5)",fontSize:11}}>ผู้ตรวจเวร</div>
            <div style={{color:"#FFD700",fontWeight:700,fontSize:14}}>{entry.inspector}</div>
          </div>
        </div>
      </div>

      <div style={{padding:"20px 24px"}}>
        {/* controls */}
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:16}}>
          <div>
            <label style={{fontSize:11,color:"#888",display:"block",marginBottom:4,fontWeight:600}}>📅 วันที่รายงาน</label>
            <input value={repDate} onChange={e=>setRepDate(e.target.value)}
              style={{width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #d0dff0",fontSize:14,fontFamily:"Sarabun,sans-serif",boxSizing:"border-box",color:"#1a3a6b",fontWeight:600}} />
          </div>
          <div>
            <label style={{fontSize:11,color:"#888",display:"block",marginBottom:4,fontWeight:600}}>🕐 ช่วงเวลาเวร</label>
            <select value={selShift} onChange={e=>setSelShift(e.target.value)}
              style={{width:"100%",padding:"9px 12px",borderRadius:9,border:"1.5px solid #d0dff0",fontSize:13,fontFamily:"Sarabun,sans-serif",color:"#1a3a6b",fontWeight:600}}>
              {SHIFT_KEYS.map(k=><option key={k} value={k}>{SHIFT_LABELS[k]}</option>)}
            </select>
          </div>
        </div>

        {/* electrical workers */}
        <div style={{marginBottom:18,padding:"12px 14px",borderRadius:12,background:"#f0faf3",border:"1.5px solid #a7d9b2"}}>
          <label style={{fontSize:11,color:"#1a5c2a",display:"block",marginBottom:8,fontWeight:700}}>🔧 เลือกผู้ปฏิบัติงานระบบไฟฟ้า (เลือก 2 คน)</label>
          <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
            {ELECTRICAL_WORKERS.map(w=>{
              const sel=!!selWorkers.find(p=>p.id===w.id);
              const idx=selWorkers.findIndex(p=>p.id===w.id);
              return (
                <button key={w.id} onClick={()=>setSelWorkers(prev=>{
                  if(prev.find(p=>p.id===w.id)) return prev.filter(p=>p.id!==w.id);
                  if(prev.length>=2) return [prev[1],w];
                  return [...prev,w];
                })} style={{padding:"5px 12px",borderRadius:99,fontSize:12,border:"1.5px solid",cursor:"pointer",fontFamily:"Sarabun,sans-serif",fontWeight:600,
                  background:sel?"#1a5c2a":"white",color:sel?"white":"#333",borderColor:sel?"#1a5c2a":"#c0d8c0",
                  display:"flex",alignItems:"center",gap:4}}>
                  {sel&&<span style={{fontSize:10,background:"rgba(255,255,255,0.3)",borderRadius:"50%",width:16,height:16,display:"inline-flex",alignItems:"center",justifyContent:"center"}}>{idx+1}</span>}
                  {w.fullname.split(" ")[0]}
                </button>
              );
            })}
          </div>
        </div>

        {/* preview */}
        <div style={{borderRadius:14,border:"2px solid #1a3a6b",overflow:"hidden",marginBottom:18,boxShadow:"0 4px 20px rgba(26,58,107,0.12)"}}>
          <div style={{background:"#f5f8ff",borderBottom:"2px solid #1a3a6b",padding:"12px 16px"}}>
            <div style={{fontWeight:700,fontSize:14,color:"#1a3a6b",lineHeight:1.7}}>เรียน ผจก.กฟส.ชยน.ผ่าน หผ.ปร.</div>
            <div style={{fontSize:13,color:"#444",lineHeight:1.7}}>ลว. <b>{repDate}</b> &nbsp;&nbsp;&nbsp; เวลา <b>{SHIFT_LABELS[selShift]}</b></div>
            <div style={{fontSize:13,color:"#1a3a6b",fontWeight:600,marginTop:2}}>⚡ พนักงานอยู่เวรแก้กระแสไฟฟ้าขัดข้อง ดังนี้</div>
          </div>
          <div style={{background:"white"}}>
            {previewRows.map((row,i)=>(
              <div key={i} style={{display:"flex",alignItems:"flex-start",gap:10,padding:"9px 16px",
                background:i%2===0?row.bg:"white",
                borderBottom:i<previewRows.length-1?"1px solid #eef2f8":"none"}}>
                <div style={{width:26,height:26,borderRadius:"50%",background:row.bg,border:`1.5px solid ${row.color}33`,
                  display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,marginTop:1,fontSize:14}}>
                  {row.icon}
                </div>
                <div style={{display:"flex",alignItems:"baseline",gap:6,flexWrap:"wrap",flex:1}}>
                  <span style={{fontWeight:700,color:"#333",fontSize:13,minWidth:20}}>{row.n}.</span>
                  <span style={{color:row.color,fontSize:13,fontWeight:600}}>{row.text}</span>
                  {row.sub&&<span style={{color:"#666",fontSize:12,background:"#f0f4ff",borderRadius:6,padding:"1px 7px"}}>{row.sub}</span>}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* hidden textarea for execCommand copy */}
        <textarea
          ref={textareaRef}
          readOnly
          value={text}
          style={{position:"absolute",left:-9999,top:-9999,opacity:0,pointerEvents:"none",width:1,height:1}}
        />

        {/* copy button */}
        <button onClick={handleCopy}
          style={{width:"100%",padding:"14px",borderRadius:12,border:"none",fontWeight:700,fontSize:15,cursor:"pointer",fontFamily:"Sarabun,sans-serif",
            transition:"all 0.2s",
            background:copyStatus==="success"?"linear-gradient(90deg,#16a34a,#15803d)":"linear-gradient(90deg,#1a3a6b,#2a5298)",
            color:copyStatus==="success"?"white":"#FFD700",
            boxShadow:copyStatus==="success"?"0 4px 14px rgba(22,163,74,0.4)":"0 4px 14px rgba(26,58,107,0.35)",
            marginBottom: copyStatus==="manual" ? 10 : 0}}>
          {copyStatus==="success"?"✅ คัดลอกสำเร็จแล้ว!":"📋 คัดลอกรายงานเวร"}
        </button>

        {/* fallback: visible textarea for manual copy */}
        {copyStatus==="manual" && (
          <div style={{borderRadius:12,border:"2px solid #f0a500",overflow:"hidden"}}>
            <div style={{background:"#1a3a6b",padding:"9px 14px",display:"flex",alignItems:"center",gap:8}}>
              <span>📋</span>
              <span style={{color:"#FFD700",fontWeight:700,fontSize:12}}>กด Ctrl+A แล้ว Ctrl+C เพื่อคัดลอก</span>
              <button onClick={()=>setCopyStatus("idle")} style={{marginLeft:"auto",background:"rgba(255,255,255,0.15)",border:"none",color:"white",borderRadius:6,padding:"2px 8px",cursor:"pointer",fontSize:12}}>✕</button>
            </div>
            <textarea
              readOnly
              value={text}
              onClick={e=>{ e.target.select(); e.target.setSelectionRange(0,99999); }}
              style={{width:"100%",padding:"14px",border:"none",fontSize:13,fontFamily:"Sarabun,sans-serif",lineHeight:2,resize:"none",outline:"none",boxSizing:"border-box",color:"#1a2a4a",minHeight:200,display:"block"}}
            />
          </div>
        )}
      </div>
    </div>
  );
}


export default ReportModal
