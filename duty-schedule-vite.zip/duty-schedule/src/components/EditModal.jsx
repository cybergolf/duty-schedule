import { useState } from 'react'
import { EMPLOYEES, INSPECTORS } from '../data/employees'
import { SHIFT_KEYS, SHIFT_LABELS, SHIFT_SHORT } from '../data/schedule'

function EditModal({ entry, onSave, onClose }) {
  const [form, setForm] = useState({
    shift0030: [...entry.shift0030],
    shift0830: [...entry.shift0830],
    shift1630: [...entry.shift1630],
    standby:   entry.standby,
    inspector: entry.inspector,
    note:      entry.note,
  });
  const [activeShift, setActiveShift] = useState("shift1630");
  const [swapMode,    setSwapMode]    = useState(false);
  const [swapSel,     setSwapSel]     = useState(null);

  const setShiftPerson = (sk, idx, val) =>
    setForm(f => { const a=[...f[sk]]; a[idx]=val; return {...f,[sk]:a}; });

  const addPerson = (sk) =>
    setForm(f => ({...f,[sk]:[...f[sk],""]}));

  const removePerson = (sk, idx) =>
    setForm(f => ({...f,[sk]:f[sk].filter((_,i)=>i!==idx)}));

  const handleSwap = (sk, idx) => {
    if (!swapSel) { setSwapSel({sk,idx}); return; }
    if (swapSel.sk===sk && swapSel.idx===idx) { setSwapSel(null); return; }
    setForm(f => {
      const n = {shift0030:[...f.shift0030],shift0830:[...f.shift0830],shift1630:[...f.shift1630]};
      const tmp = n[swapSel.sk][swapSel.idx];
      n[swapSel.sk][swapSel.idx] = n[sk][idx];
      n[sk][idx] = tmp;
      return {...f,...n};
    });
    setSwapSel(null);
  };

  const isSelected = (sk,idx) => swapSel && swapSel.sk===sk && swapSel.idx===idx;

  return (
    <div style={{padding:24,fontFamily:"Sarabun,sans-serif"}}>
      {/* header */}
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20,borderBottom:"2px solid #1a3a6b",paddingBottom:14,flexWrap:"wrap"}}>
        <div style={{width:44,height:44,borderRadius:"50%",background:"#1a3a6b",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
          <span style={{fontSize:20}}>✏️</span>
        </div>
        <div style={{flex:1}}>
          <div style={{fontWeight:700,fontSize:18,color:"#1a3a6b"}}>แก้ไขตารางเวร</div>
          <div style={{fontSize:13,color:"#666"}}>วันที่ {entry.day} มีนาคม พ.ศ. 2569</div>
        </div>
        <button onClick={()=>{setSwapMode(m=>!m);setSwapSel(null);}} style={{
          padding:"7px 14px",borderRadius:10,border:"2px solid",fontSize:13,fontWeight:700,cursor:"pointer",fontFamily:"Sarabun,sans-serif",
          borderColor: swapMode?"#e67e22":"#1a3a6b",
          background:  swapMode?"#fff3e0":"#eef2ff",
          color:       swapMode?"#c0392b":"#1a3a6b"}}>
          🔄 {swapMode?"โหมดสลับเวร (ON)":"โหมดสลับเวร"}
        </button>
      </div>

      {/* swap hint */}
      {swapMode && (
        <div style={{background:"#fff3e0",border:"1px solid #f0a500",borderRadius:10,padding:"10px 14px",marginBottom:16,fontSize:13,color:"#7a4400",lineHeight:1.6}}>
          {swapSel
            ? <><b>เลือกแล้ว:</b> {form[swapSel.sk][swapSel.idx]} ({SHIFT_LABELS[swapSel.sk]}) — คลิกชื่อที่ต้องการสลับด้วย</>
            : "คลิกชื่อพนักงานคนแรกที่ต้องการสลับ (สลับข้ามช่วงเวลาได้)"}
        </div>
      )}

      {/* shift tabs */}
      <div style={{display:"flex",gap:6,marginBottom:14}}>
        {SHIFT_KEYS.map(sk=>(
          <button key={sk} onClick={()=>setActiveShift(sk)} style={{
            flex:1,padding:"8px 4px",borderRadius:10,border:"2px solid",fontSize:12,fontWeight:700,cursor:"pointer",fontFamily:"Sarabun,sans-serif",
            borderColor: activeShift===sk?"#1a3a6b":"#e0e0e0",
            background:  activeShift===sk?"#1a3a6b":"#f8f9fa",
            color:       activeShift===sk?"#FFD700":"#555"}}>
            {SHIFT_SHORT[sk]}
          </button>
        ))}
      </div>

      {/* shift person list */}
      {SHIFT_KEYS.map(sk => activeShift!==sk ? null : (
        <div key={sk} style={{marginBottom:8}}>
          <div style={{fontSize:12,color:"#888",marginBottom:8}}>
            รายชื่อ {SHIFT_LABELS[sk]}
            <span style={{marginLeft:8,color:"#1a3a6b",fontWeight:600}}>คนแรก = หัวหน้าเวร ★</span>
          </div>

          {form[sk].length === 0 && (
            <div style={{color:"#bbb",fontSize:13,marginBottom:10,padding:"10px",border:"1px dashed #ddd",borderRadius:10,textAlign:"center"}}>
              — ไม่มีผู้เข้าเวร —
            </div>
          )}

          {form[sk].map((nick,i)=>(
            <div key={i} style={{display:"flex",alignItems:"center",gap:8,marginBottom:8}}>
              <div style={{width:28,height:28,borderRadius:"50%",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",
                background: i===0?"#1a3a6b":"#e8f0fb",
                color: i===0?"#FFD700":"#1a3a6b",fontSize:12,fontWeight:700}}>
                {i===0?"★":i+1}
              </div>

              {swapMode ? (
                <button onClick={()=>handleSwap(sk,i)} style={{
                  flex:1,padding:"9px 14px",borderRadius:10,border:"2px solid",cursor:"pointer",
                  fontFamily:"Sarabun,sans-serif",fontWeight:700,fontSize:14,textAlign:"left",
                  background: isSelected(sk,i)?"#fff3e0":"#f8f9fa",
                  borderColor: isSelected(sk,i)?"#e67e22":"#c8d8e8",
                  color: isSelected(sk,i)?"#c0392b":"#1a3a6b"}}>
                  {nick||"(ว่าง)"} {isSelected(sk,i)&&"🔄"}
                </button>
              ) : (
                <select value={nick} onChange={e=>setShiftPerson(sk,i,e.target.value)} style={{
                  flex:1,padding:"9px 12px",borderRadius:10,border:"1px solid #ddd",
                  fontSize:14,fontFamily:"Sarabun,sans-serif",color:"#333"}}>
                  <option value="">— เลือกพนักงาน —</option>
                  {EMPLOYEES.map(e=>(
                    <option key={e.id} value={e.nickname}>{e.nickname} ({e.position})</option>
                  ))}
                </select>
              )}

              {!swapMode && (
                <button onClick={()=>removePerson(sk,i)} style={{
                  width:32,height:32,borderRadius:"50%",border:"none",cursor:"pointer",flexShrink:0,
                  background:"#fee2e2",color:"#dc2626",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center"}}>
                  ×
                </button>
              )}
            </div>
          ))}

          {!swapMode && (
            <button onClick={()=>addPerson(sk)} style={{
              width:"100%",padding:"9px",borderRadius:10,border:"2px dashed #b0c8e8",
              background:"#f0f6ff",color:"#1a3a6b",fontWeight:700,fontSize:13,cursor:"pointer",fontFamily:"Sarabun,sans-serif"}}>
              + เพิ่มพนักงานในช่วงนี้
            </button>
          )}
        </div>
      ))}

      {/* standby / inspector / note */}
      <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10,marginTop:18}}>
        <div>
          <label style={{fontSize:12,color:"#666",display:"block",marginBottom:4}}>Standby (00.30-08.30)</label>
          <select value={form.standby} onChange={e=>setForm(f=>({...f,standby:e.target.value}))} style={{width:"100%",padding:"8px",borderRadius:8,border:"1px solid #ddd",fontSize:13,fontFamily:"Sarabun,sans-serif"}}>
            {EMPLOYEES.map(e=><option key={e.id} value={e.nickname}>{e.nickname}</option>)}
          </select>
        </div>
        <div>
          <label style={{fontSize:12,color:"#666",display:"block",marginBottom:4}}>ผู้ตรวจเวร</label>
          <select value={form.inspector} onChange={e=>setForm(f=>({...f,inspector:e.target.value}))} style={{width:"100%",padding:"8px",borderRadius:8,border:"1px solid #ddd",fontSize:13,fontFamily:"Sarabun,sans-serif"}}>
            {INSPECTORS.map(e=><option key={e.id} value={e.nickname}>{e.nickname}</option>)}
          </select>
        </div>
        <div>
          <label style={{fontSize:12,color:"#666",display:"block",marginBottom:4}}>หมายเหตุ</label>
          <select value={form.note} onChange={e=>setForm(f=>({...f,note:e.target.value}))} style={{width:"100%",padding:"8px",borderRadius:8,border:"1px solid #ddd",fontSize:13,fontFamily:"Sarabun,sans-serif"}}>
            {["","เสาร์","อาทิตย์","หยุด"].map(n=><option key={n} value={n}>{n||"— ปกติ —"}</option>)}
          </select>
        </div>
      </div>

      {/* buttons */}
      <div style={{display:"flex",gap:10,marginTop:22}}>
        <button onClick={onClose} style={{flex:1,padding:"12px",borderRadius:12,border:"2px solid #ddd",background:"#f8f9fa",color:"#666",fontWeight:700,fontSize:15,cursor:"pointer",fontFamily:"Sarabun,sans-serif"}}>
          ยกเลิก
        </button>
        <button onClick={()=>onSave(entry.day,form)} style={{flex:2,padding:"12px",borderRadius:12,border:"none",background:"linear-gradient(90deg,#1a3a6b,#2a5298)",color:"#FFD700",fontWeight:700,fontSize:15,cursor:"pointer",fontFamily:"Sarabun,sans-serif"}}>
          ✅ บันทึกการแก้ไข
        </button>
      </div>
    </div>
  );
}


export default EditModal
